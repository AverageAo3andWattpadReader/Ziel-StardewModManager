import tkinter as tk
from pynput import keyboard
import pyautogui
import threading

running = True

def copy_mouse_position():
    x, y = pyautogui.position()
    root.clipboard_clear()
    root.clipboard_append(f"{x}, {y}")
    label.config(text=f"Copied: {x}, {y}")

def stop_program():
    global running
    running = False
    root.quit()

def on_press(key):
    try:
        if key.char == "[":
            copy_mouse_position()
        elif key.char == "]":
            stop_program()
    except:
        pass

def keyboard_listener():
    with keyboard.Listener(on_press=on_press) as listener:
        listener.join()

def update_mouse_position():
    if running:
        x, y = pyautogui.position()
        coord_label.config(text=f"Mouse: {x}, {y}")
        root.after(50, update_mouse_position)  # refresh rate

root = tk.Tk()
root.title("Mouse Tracker")
root.geometry("260x140")
root.attributes("-topmost", True)

label = tk.Label(root, text="[ = copy position\n] = exit", font=("Arial", 10))
label.pack()

coord_label = tk.Label(root, text="Mouse: 0, 0", font=("Arial", 11))
coord_label.pack(pady=10)

thread = threading.Thread(target=keyboard_listener, daemon=True)
thread.start()

update_mouse_position()

root.mainloop()