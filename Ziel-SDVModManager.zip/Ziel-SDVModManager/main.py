import re
import shutil
import tkinter as tk
from tkinter import ttk, filedialog, messagebox, scrolledtext
import subprocess
import os
import threading
import time
import pyautogui
import pyperclip
from pynput import keyboard
from pathlib import Path
from typing import Tuple, Dict, Optional

# --- Utility functions (shared across modules) ---
# Common regex patterns
word_re = re.compile(r"[a-z]+")

def normalize_name(name: str) -> set:
    name = name.lower()
    return set(word_re.findall(name))

def parse_version(name: str) -> Optional[Tuple[Tuple[int, ...], int]]:
    parts = name.rsplit("-", maxsplit=5)
    if len(parts) < 6:
        return None
    try:
        version = tuple(map(int, parts[2:5]))
        timestamp = int(parts[5])
        return version, timestamp
    except ValueError:
        return None

# --- Mod Cleaner ---
class ModCleanerTab(ttk.Frame):
    def __init__(self, parent):
        super().__init__(parent)
        self.new_mods_dir = None
        self.mods_dir = None
        self.trashed_dir = None
        self._build_ui()

    def _build_ui(self):
        btn_frame = ttk.Frame(self)
        btn_frame.pack(padx=10, pady=10, fill=tk.X)

        ttk.Button(btn_frame, text="Select 'new mods' folder", command=self.select_new_mods).pack(fill=tk.X)
        ttk.Button(btn_frame, text="Select 'mods' folder", command=self.select_mods).pack(fill=tk.X)
        ttk.Button(btn_frame, text="Select 'trashed' folder", command=self.select_trashed).pack(fill=tk.X)
        ttk.Button(btn_frame, text="Run Scan", command=self.run_scan).pack(fill=tk.X, pady=5)

        self.log = scrolledtext.ScrolledText(self, height=20)
        self.log.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)

    def log_msg(self, msg):
        self.log.insert(tk.END, msg + "\n")
        self.log.see(tk.END)

    def select_new_mods(self):
        path = filedialog.askdirectory(title="Select 'new mods' folder")
        if path:
            self.new_mods_dir = Path(path)
            self.log_msg(f"[SET] new mods = {path}")

    def select_mods(self):
        path = filedialog.askdirectory(title="Select 'mods' folder")
        if path:
            self.mods_dir = Path(path)
            self.log_msg(f"[SET] mods = {path}")

    def select_trashed(self):
        path = filedialog.askdirectory(title="Select 'trashed' folder")
        if path:
            self.trashed_dir = Path(path)
            self.log_msg(f"[SET] trashed = {path}")

    def run_scan(self):
        if not all([self.new_mods_dir, self.mods_dir, self.trashed_dir]):
            messagebox.showerror("Error", "All folders must be selected.")
            return

        self.log_msg("\n--- Scan Started ---")
        new_index = build_index(self.new_mods_dir)
        mods_index = build_index(self.mods_dir)
        moved = 0

        for new_name, new_entry in new_index.items():
            match = best_match(new_entry["words"], mods_index)
            if not match:
                self.log_msg(f"[UNDETECTED] {new_name}")
                continue

            old_path = match["path"]
            self.log_msg(f"[MATCH] {old_path.name} ↔ {new_name}")

            if not new_entry["version"] or not match["version"]:
                self.log_msg("[SKIP] Missing version info")
                continue

            old_ver, old_ts = match["version"]
            new_ver, new_ts = new_entry["version"]

            if (old_ver, old_ts) < (new_ver, new_ts):
                dest = self.trashed_dir / old_path.name
                self.log_msg(f"[MOVE] {old_path.name} → trashed")
                shutil.move(str(old_path), str(dest))
                moved += 1
            else:
                self.log_msg("[KEEP] Existing mod is newer or equal")
        self.log_msg(f"\n--- Done. Moved {moved} outdated mod(s). ---\n")

def build_index(folder: Path) -> dict:
    index = {}
    for item in folder.iterdir():
        if not item.is_dir():
            continue
        words = normalize_name(item.name)
        ver = parse_version(item.name)
        index[item.name] = {
            "path": item,
            "words": words,
            "version": ver,
        }
    return index

def best_match(new_words, mods_index):
    best = None
    best_score = 0
    for entry in mods_index.values():
        overlap = len(new_words & entry["words"])
        if overlap >= 2 and overlap > best_score:
            best = entry
            best_score = overlap
    return best

# --- SMAPI Extractor ---
class SMAPIExtractorTab(ttk.Frame):
    def __init__(self, parent):
        super().__init__(parent)
        self._build_ui()

    def _build_ui(self):
        ttk.Label(self, text="Input List").pack()
        self.input_box = tk.Text(self, height=8)
        self.input_box.pack(fill="both", padx=10, pady=5)

        ttk.Button(self, text="Extract", command=self.extract).pack(pady=5)

        ttk.Label(self, text="Mod Names").pack()
        self.name_box = tk.Text(self, height=6)
        self.name_box.pack(fill="both", padx=10, pady=5)

        ttk.Label(self, text="URLs").pack()
        self.url_box = tk.Text(self, height=6)
        self.url_box.pack(fill="both", padx=10, pady=5)

    def extract(self):
        input_text = self.input_box.get("1.0", tk.END).strip().splitlines()

        urls = []
        names = []

        for line in input_text:
            url_match = re.search(r"https://\S+", line)
            if not url_match:
                continue
            url = url_match.group(0)
            before_url = line[:url_match.start()]

            if "]" in before_url:
                before_url = before_url.split("]", 1)[1].strip()

            parts = before_url.rsplit(" ", 1)
            name = parts[0] if len(parts) > 1 else before_url

            names.append(name.strip())
            urls.append(url.strip())

        # Remove duplicates
        urls = list(dict.fromkeys(urls))

        # Clear output boxes
        self.name_box.delete("1.0", tk.END)
        self.url_box.delete("1.0", tk.END)

        # Insert results
        self.name_box.insert(tk.END, "\n".join(names))
        self.url_box.insert(tk.END, "\n".join(urls))

        # Save URLs to file and open
        if urls:
            file_path = "urls.txt"
            with open(file_path, "w", encoding="utf-8") as f:
                f.write("\n".join(urls))
            subprocess.Popen(["notepad.exe", file_path])

# --- Link Opener ---
class URLAutoOpenerTab(ttk.Frame):
    def __init__(self, parent):
        super().__init__(parent)

        self.running = False
        self._build_ui()

        # Load settings
        self.settings_file = "settings.json"
        self.load_settings()
        self.load_settings_ui()

        # Hotkeys
        self.listener = keyboard.Listener(on_press=self.on_press)
        self.listener.start()

    def _build_ui(self):
        frame = self
        ttk.Button(frame, text="START", command=self.start).pack(fill="x", pady=5)
        ttk.Button(frame, text="STOP", command=self.stop).pack(fill="x", pady=5)
        ttk.Button(frame, text="SAVE SETTINGS", command=self.save_settings).pack(fill="x", pady=5)
        self.status_label = ttk.Label(frame, text="Idle")
        self.status_label.pack(pady=5)

        # Coordinates
        ttk.Label(frame, text="Click X").pack()
        self.click_x_entry = ttk.Entry(frame)
        self.click_x_entry.insert(0, "486")
        self.click_x_entry.pack(fill="x", pady=2)

        ttk.Label(frame, text="Click Y").pack()
        self.click_y_entry = ttk.Entry(frame)
        self.click_y_entry.insert(0, "20")
        self.click_y_entry.pack(fill="x", pady=2)

        # Delay boxes
        def delay_box(label_text):
            ttk.Label(frame, text=label_text).pack()
            e = ttk.Entry(frame)
            e.insert(0, "1")
            e.pack(fill="x", pady=2)
            return e

        self.delay_click = delay_box("Delay before CLICK")
        self.delay_paste = delay_box("Delay before PASTE")
        self.delay_enter = delay_box("Delay before ENTER")
        self.delay_tab = delay_box("Delay before NEW TAB")

    def load_settings(self):
        if os.path.exists(self.settings_file):
            import json
            with open(self.settings_file, "r", encoding="utf-8") as f:
                self.settings = json.load(f)
        else:
            self.settings = {
                "x": 486,
                "y": 20,
                "click": "1",
                "paste": "1",
                "enter": "1",
                "tab": "1"
            }

    def load_settings_ui(self):
        s = self.settings
        self.click_x_entry.delete(0, tk.END)
        self.click_x_entry.insert(0, s.get("x", 486))
        self.click_y_entry.delete(0, tk.END)
        self.click_y_entry.insert(0, s.get("y", 20))
        self.delay_click.delete(0, tk.END)
        self.delay_click.insert(0, s.get("click", "1"))
        self.delay_paste.delete(0, tk.END)
        self.delay_paste.insert(0, s.get("paste", "1"))
        self.delay_enter.delete(0, tk.END)
        self.delay_enter.insert(0, s.get("enter", "1"))
        self.delay_tab.delete(0, tk.END)
        self.delay_tab.insert(0, s.get("tab", "1"))

    def save_settings(self):
        s = {
            "x": self.click_x_entry.get(),
            "y": self.click_y_entry.get(),
            "click": self.delay_click.get(),
            "paste": self.delay_paste.get(),
            "enter": self.delay_enter.get(),
            "tab": self.delay_tab.get()
        }
        with open(self.settings_file, "w", encoding="utf-8") as f:
            import json
            json.dump(s, f)
        self.status_label.config(text="Settings saved")

    def get_delay(self, entry):
        try:
            return float(entry.get())
        except:
            return 1.0

    def get_coords(self):
        try:
            return int(self.click_x_entry.get()), int(self.click_y_entry.get())
        except:
            return 486, 20

    def load_urls(self):
        file_path = "urls.txt"
        if not os.path.exists(file_path):
            return []
        with open(file_path, "r", encoding="utf-8") as f:
            return [line.strip() for line in f if line.strip()]

    def worker(self):
        urls = self.load_urls()
        if not urls:
            self.status_label.after(0, lambda: self.status_label.config(text="No URLs loaded"))
            self.running = False
            return
        self.status_label.after(0, lambda: self.status_label.config(text=f"Running ({len(urls)} URLs)"))
        time.sleep(3)
        for url in urls:
            if not self.running:
                break
            x, y = self.get_coords()
            d_click = self.get_delay(self.delay_click)
            d_paste = self.get_delay(self.delay_paste)
            d_enter = self.get_delay(self.delay_enter)
            d_tab = self.get_delay(self.delay_tab)

            pyperclip.copy(url)
            time.sleep(d_click)
            pyautogui.click(x, y)
            time.sleep(d_paste)
            pyautogui.hotkey("ctrl", "v")
            time.sleep(d_enter)
            pyautogui.press("enter")
            time.sleep(d_tab)
            pyautogui.hotkey("ctrl", "t")
        self.status_label.after(0, lambda: self.status_label.config(text="Stopped"))
        self.running = False

    def start(self):
        if self.running:
            return
        self.running = True
        threading.Thread(target=self.worker, daemon=True).start()

    def stop(self):
        self.running = False
        self.status_label.config(text="Stopping...")

    def on_press(self, key):
        try:
            if key.char == "[":
                self.start()
            elif key.char == "]":
                self.stop()
        except:
            pass

# --- Main Application ---
class MainApp(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("Unified Tool Suite")
        self.geometry("1000x700")
        tab_control = ttk.Notebook(self)

        # Add tabs
        tab_control.add(ModCleanerTab(tab_control), text='Mod Cleaner')
        tab_control.add(SMAPIExtractorTab(tab_control), text='SMAPI Extractor')
        tab_control.add(URLAutoOpenerTab(tab_control), text='URL Opener')

        tab_control.pack(expand=1, fill='both')


if __name__ == "__main__":
    app = MainApp()
    app.mainloop()