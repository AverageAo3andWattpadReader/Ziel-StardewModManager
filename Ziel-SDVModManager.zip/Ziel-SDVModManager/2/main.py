#!/usr/bin/env python3
"""
File: mod_cleaner_gui.py

GUI tool to detect outdated mods in `mods` by comparing against
newer mods inside `new mods`, then move outdated ones to `trashed`.
"""

from __future__ import annotations

import re
import shutil
from pathlib import Path
from typing import Tuple, Dict, Optional
import tkinter as tk
from tkinter import filedialog, messagebox, scrolledtext


WORD_RE = re.compile(r"[a-z]+")


def normalize_name(name: str) -> set[str]:
    name = name.lower()
    words = WORD_RE.findall(name)
    return set(words)


def parse_version(name: str) -> Optional[Tuple[Tuple[int, ...], int]]:
    parts = name.rsplit("-", maxsplit=5)
    if len(parts) < 6:
        return None
    try:
        version = tuple(map(int, parts[2:5]))
        timestamp = int(parts[5])
        return version, timestamp
    except ValueError:
        return None


def build_index(folder: Path) -> Dict[str, dict]:
    index = {}

    for item in folder.iterdir():
        if not item.is_dir():
            continue

        words = normalize_name(item.name)
        ver = parse_version(item.name)

        index[item.name] = {
            "path": item,
            "words": words,
            "version": ver,
        }

    return index


def best_match(new_words: set[str], mods_index: Dict[str, dict]) -> Optional[dict]:
    best = None
    best_score = 0

    for entry in mods_index.values():
        overlap = len(new_words & entry["words"])
        if overlap >= 2 and overlap > best_score:
            best = entry
            best_score = overlap

    return best


class ModCleanerGUI(tk.Tk):
    def __init__(self) -> None:
        super().__init__()

        self.title("Mod Cleaner")
        self.geometry("900x600")

        self.new_mods_dir: Path | None = None
        self.mods_dir: Path | None = None
        self.trashed_dir: Path | None = None

        self._build_ui()

    def _build_ui(self) -> None:
        frame = tk.Frame(self)
        frame.pack(padx=10, pady=10, fill=tk.X)

        tk.Button(frame, text="Select 'new mods' folder", command=self.select_new_mods).pack(fill=tk.X)
        tk.Button(frame, text="Select 'mods' folder", command=self.select_mods).pack(fill=tk.X)
        tk.Button(frame, text="Select 'trashed' folder", command=self.select_trashed).pack(fill=tk.X)
        tk.Button(frame, text="Run Scan", command=self.run_scan).pack(fill=tk.X, pady=10)

        self.log = scrolledtext.ScrolledText(self, height=25)
        self.log.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)

    def log_msg(self, msg: str) -> None:
        self.log.insert(tk.END, msg + "\n")
        self.log.see(tk.END)

    def select_new_mods(self) -> None:
        path = filedialog.askdirectory(title="Select 'new mods' folder")
        if path:
            self.new_mods_dir = Path(path)
            self.log_msg(f"[SET] new mods = {path}")

    def select_mods(self) -> None:
        path = filedialog.askdirectory(title="Select 'mods' folder")
        if path:
            self.mods_dir = Path(path)
            self.log_msg(f"[SET] mods = {path}")

    def select_trashed(self) -> None:
        path = filedialog.askdirectory(title="Select 'trashed' folder")
        if path:
            self.trashed_dir = Path(path)
            self.log_msg(f"[SET] trashed = {path}")

    def run_scan(self) -> None:
        if not all([self.new_mods_dir, self.mods_dir, self.trashed_dir]):
            messagebox.showerror("Error", "All folders must be selected.")
            return

        self.log_msg("\n--- Scan Started ---")

        new_index = build_index(self.new_mods_dir)
        mods_index = build_index(self.mods_dir)

        moved = 0

        for new_name, new_entry in new_index.items():
            match = best_match(new_entry["words"], mods_index)

            if not match:
                self.log_msg(f"[UNDETECTED] {new_name}")
                continue

            old_path = match["path"]
            self.log_msg(f"[MATCH] {old_path.name} ↔ {new_name}")

            if not new_entry["version"] or not match["version"]:
                self.log_msg("[SKIP] Missing version info")
                continue

            old_ver, old_ts = match["version"]
            new_ver, new_ts = new_entry["version"]

            if (old_ver, old_ts) < (new_ver, new_ts):
                dest = self.trashed_dir / old_path.name
                self.log_msg(f"[MOVE] {old_path.name} → trashed")
                shutil.move(str(old_path), str(dest))
                moved += 1
            else:
                self.log_msg("[KEEP] Existing mod is newer or equal")

        self.log_msg(f"\n--- Done. Moved {moved} outdated mod(s). ---\n")


def main() -> None:
    app = ModCleanerGUI()
    app.mainloop()


if __name__ == "__main__":
    main()
