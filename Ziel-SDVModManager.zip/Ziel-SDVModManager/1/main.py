import re
import tkinter as tk
from tkinter import ttk
import subprocess
import os

pattern = re.compile(r":\s(.+?)\s[^:]+:\s(https://\S+)")

url_pattern = re.compile(r"https://\S+")

def extract():
    input_text = input_box.get("1.0", tk.END).strip().splitlines()

    names = []
    urls = []

    for line in input_text:
        url_match = url_pattern.search(line)
        if not url_match:
            continue

        url = url_match.group(0)

        # Get everything before the URL
        before_url = line[:url_match.start()]

        # Removes prefix
        if "]" in before_url:
            before_url = before_url.split("]", 1)[1].strip()

        # Remove version (last chunk)
        parts = before_url.rsplit(" ", 1)
        name = parts[0] if len(parts) > 1 else before_url

        names.append(name.strip())
        urls.append(url.strip())

    # remove duplicates
    urls = list(dict.fromkeys(urls))

    # clear outputs
    name_box.delete("1.0", tk.END)
    url_box.delete("1.0", tk.END)

    # insert results
    name_box.insert(tk.END, "\n".join(names))
    url_box.insert(tk.END, "\n".join(urls))

    # save + open txt
    if urls:
        file_path = "urls.txt"
        with open(file_path, "w", encoding="utf-8") as f:
            f.write("\n".join(urls))

        import subprocess
        subprocess.Popen(["notepad.exe", file_path])


# GUI setup
root = tk.Tk()
root.title("SMAPI Extractor")
root.geometry("700x500")

ttk.Label(root, text="Input List").pack()
input_box = tk.Text(root, height=8)
input_box.pack(fill="both", padx=10, pady=5)

extract_btn = ttk.Button(root, text="Extract", command=extract)
extract_btn.pack(pady=5)

ttk.Label(root, text="Mod Names").pack()
name_box = tk.Text(root, height=6)
name_box.pack(fill="both", padx=10, pady=5)

ttk.Label(root, text="URLs").pack()
url_box = tk.Text(root, height=6)
url_box.pack(fill="both", padx=10, pady=5)

root.mainloop()