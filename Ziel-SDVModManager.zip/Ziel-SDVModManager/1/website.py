import tkinter as tk
from tkinter import ttk
import pyautogui
import pyperclip
import time
import threading
import os
from pynput import keyboard

# === CONFIG ===
URL_FILE = "urls.txt"

running = False

def load_urls():
    if not os.path.exists(URL_FILE):
        status_label.config(text="urls.txt not found")
        return []
    with open(URL_FILE, "r", encoding="utf-8") as f:
        return [line.strip() for line in f if line.strip()]

def get_delay(entry):
    try:
        return float(entry.get())
    except:
        return 1.0

def get_coords():
    try:
        x = int(click_x_entry.get())
    except:
        x = 486

    try:
        y = int(click_y_entry.get())
    except:
        y = 20

    return x, y

def worker():
    global running
    urls = load_urls()

    if not urls:
        status_label.config(text="No URLs loaded")
        running = False
        return

    status_label.config(text=f"Running ({len(urls)} URLs)")

    time.sleep(3)

    for url in urls:
        if not running:
            break

        CLICK_X, CLICK_Y = get_coords()

        d_click = get_delay(delay_click)
        d_paste = get_delay(delay_paste)
        d_enter = get_delay(delay_enter)
        d_tab = get_delay(delay_tab)

        pyperclip.copy(url)

        time.sleep(d_click)
        pyautogui.click(CLICK_X, CLICK_Y)

        time.sleep(d_paste)
        pyautogui.hotkey("ctrl", "v")

        time.sleep(d_enter)
        pyautogui.press("enter")

        time.sleep(d_tab)
        pyautogui.hotkey("ctrl", "t")

    status_label.config(text="Stopped")
    running = False

def start():
    global running
    if running:
        return
    running = True
    threading.Thread(target=worker, daemon=True).start()

def stop():
    global running
    running = False
    status_label.config(text="Stopping...")

# === HOTKEYS ===
def on_press(key):
    try:
        if key.char == "[":
            start()
        elif key.char == "]":
            stop()
    except:
        pass

listener = keyboard.Listener(on_press=on_press)
listener.start()

# === GUI ===
root = tk.Tk()
root.title("URL Auto Opener")
root.geometry("360x420")

frame = ttk.Frame(root, padding=10)
frame.pack(fill="both", expand=True)

start_btn = tk.Button(frame, text="START", bg="green", fg="white", command=start)
start_btn.pack(fill="x", pady=5)

stop_btn = tk.Button(frame, text="STOP", bg="red", fg="white", command=stop)
stop_btn.pack(fill="x", pady=5)

info_label = ttk.Label(frame, text="[ = start    ] = stop")
info_label.pack(pady=5)

# === CLICK COORDINATES UI ===
ttk.Label(frame, text="Click X").pack()
click_x_entry = ttk.Entry(frame)
click_x_entry.insert(0, "486")
click_x_entry.pack(fill="x", pady=2)

ttk.Label(frame, text="Click Y").pack()
click_y_entry = ttk.Entry(frame)
click_y_entry.insert(0, "20")
click_y_entry.pack(fill="x", pady=2)

# === PER-STEP DELAYS ===
def delay_box(label_text):
    ttk.Label(frame, text=label_text).pack()
    e = ttk.Entry(frame)
    e.insert(0, "1")
    e.pack(fill="x", pady=2)
    return e

delay_click = delay_box("Delay before CLICK")
delay_paste = delay_box("Delay before PASTE")
delay_enter = delay_box("Delay before ENTER")
delay_tab = delay_box("Delay before NEW TAB")

status_label = ttk.Label(frame, text="Idle")
status_label.pack(pady=10)

root.mainloop()